# Chrononaut :: Changes

* 2018-1130: 0.4.1.2 (Lisias) for KSP 1.4; 1.5
	+ Moved Settings file into <KSP_ROOT>/PluginData.
	+ Reissued due a dumb mistake. =/
* 2018-0803: 0.4.1.1 (Lisias) for KSP 1.4 DITCHED
	+ Moved Settings file into <KSP_ROOT>/PluginData.
* 2018-0407: 0.4.1 (Katten) for KSP 1.4.x
	+ fixed an issue in 0.3.0-0.4.0 where the mod wouldn't work if there was no settings file
	+ added the settings file in the release
* 2018-0406: 0.4.0 (Katten) for KSP 1.4.x
	+ Can now reload any textures that have been updated since the last reload, based on the file time. Will not load newly added files correctly tho.
* 2018-0402: 0.3.0 (Katten) for KSP 1.4.x
	+ Can now reload the complete structure of a model, instead of just updating the set of meshes already existing in the part, and handles several corner cases from inconsistent files in stock.
* 2018-0326: 0.2.0 (Katten) for KSP 1.4.x
	+ Now works in the VAB editor
* 2018-0325: 0.1.0 (Katten) for KSP 1.4.x
	+ Prepared a beta release

